var searchData=
[
  ['sentinel_5fdisconnect_5fhandler_5ft',['sentinel_disconnect_handler_t',['../classcpp__redis_1_1sentinel.html#a923e06b5b700c16dffec8a01d2fa9aa4',1,'cpp_redis::sentinel']]],
  ['subscribe_5fcallback_5ft',['subscribe_callback_t',['../classcpp__redis_1_1subscriber.html#ac6ab8ebc526d784e4b79a39bbd73dca8',1,'cpp_redis::subscriber']]]
];
