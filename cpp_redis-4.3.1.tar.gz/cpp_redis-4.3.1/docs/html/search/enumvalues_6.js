var searchData=
[
  ['lookup_5ffailed',['lookup_failed',['../classcpp__redis_1_1client.html#a2512bd48dd45391249a69bd720c1e4daa1c35224aee766403970dfaa34880ccde',1,'cpp_redis::client::lookup_failed()'],['../classcpp__redis_1_1subscriber.html#afc976757efd9d0ac4def6935546a2338a1c35224aee766403970dfaa34880ccde',1,'cpp_redis::subscriber::lookup_failed()']]]
];
