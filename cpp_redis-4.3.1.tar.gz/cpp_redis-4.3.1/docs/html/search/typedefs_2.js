var searchData=
[
  ['disconnection_5fhandler_5ft',['disconnection_handler_t',['../classcpp__redis_1_1network_1_1redis__connection.html#aba1a229a3d36a5540a80776ed0cf9a44',1,'cpp_redis::network::redis_connection::disconnection_handler_t()'],['../classcpp__redis_1_1network_1_1tcp__client__iface.html#a9a7d5942205db8be03da581a848b8ec0',1,'cpp_redis::network::tcp_client_iface::disconnection_handler_t()']]]
];
