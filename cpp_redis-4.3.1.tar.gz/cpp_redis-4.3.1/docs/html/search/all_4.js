var searchData=
[
  ['error',['error',['../classcpp__redis_1_1reply.html#a8e4d3fe1636627fdee6361705a2b1c1e',1,'cpp_redis::reply::error()'],['../classcpp__redis_1_1logger__iface.html#ac8353031252c80e69e35f5f131870ddf',1,'cpp_redis::logger_iface::error()'],['../classcpp__redis_1_1logger.html#aaf7f2837511f4414a4d7b7b923ebc15e',1,'cpp_redis::logger::error()']]],
  ['error_5fbuilder',['error_builder',['../classcpp__redis_1_1builders_1_1error__builder.html',1,'cpp_redis::builders::error_builder'],['../classcpp__redis_1_1builders_1_1error__builder.html#abbc5e14b66702ec8b210fb1d288d2423',1,'cpp_redis::builders::error_builder::error_builder(void)=default'],['../classcpp__redis_1_1builders_1_1error__builder.html#a2aee65fdc05abfacda73987e2cf60609',1,'cpp_redis::builders::error_builder::error_builder(const error_builder &amp;)=delete']]]
];
