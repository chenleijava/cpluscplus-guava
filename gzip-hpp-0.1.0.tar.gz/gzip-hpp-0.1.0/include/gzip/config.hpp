#pragma once

#ifndef ZLIB_CONST
#define ZLIB_CONST
#endif