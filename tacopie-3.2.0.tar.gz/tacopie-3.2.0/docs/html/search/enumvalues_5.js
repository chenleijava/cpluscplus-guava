var searchData=
[
  ['unknown',['UNKNOWN',['../classtacopie_1_1tcp__socket.html#ad8376e85df96ab9523f5d079ed7172aba696b031073e74bf2cb98e5ef201d4aa3',1,'tacopie::tcp_socket']]]
];
