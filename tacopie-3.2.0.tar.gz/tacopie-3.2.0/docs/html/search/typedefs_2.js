var searchData=
[
  ['event_5fcallback_5ft',['event_callback_t',['../classtacopie_1_1io__service.html#abb66850c32d9c724f4418d77bd04bcfd',1,'tacopie::io_service']]]
];
