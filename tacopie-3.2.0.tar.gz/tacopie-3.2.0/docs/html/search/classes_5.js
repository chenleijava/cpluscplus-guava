var searchData=
[
  ['write_5frequest',['write_request',['../structtacopie_1_1tcp__client_1_1write__request.html',1,'tacopie::tcp_client']]],
  ['write_5fresult',['write_result',['../structtacopie_1_1tcp__client_1_1write__result.html',1,'tacopie::tcp_client']]]
];
