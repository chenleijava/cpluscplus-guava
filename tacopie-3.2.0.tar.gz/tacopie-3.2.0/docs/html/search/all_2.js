var searchData=
[
  ['close',['close',['../classtacopie_1_1tcp__socket.html#ad5a30b17b1dad9f0ff40305e246a9213',1,'tacopie::tcp_socket']]],
  ['clr_5fbuffer',['clr_buffer',['../classtacopie_1_1self__pipe.html#a4f55a34bd882d59bdcc73b87222ba3d8',1,'tacopie::self_pipe']]],
  ['connect',['connect',['../classtacopie_1_1tcp__client.html#a0cfbb18cb72aa3b6a41921f61cacc425',1,'tacopie::tcp_client::connect()'],['../classtacopie_1_1tcp__socket.html#a6748c78312763dca6b8be05c4c8c3419',1,'tacopie::tcp_socket::connect()']]]
];
