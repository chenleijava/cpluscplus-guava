var searchData=
[
  ['self_5fpipe',['self_pipe',['../classtacopie_1_1self__pipe.html',1,'tacopie']]]
];
