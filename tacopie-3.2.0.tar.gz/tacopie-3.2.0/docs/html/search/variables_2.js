var searchData=
[
  ['size',['size',['../structtacopie_1_1tcp__client_1_1write__result.html#acee9eca954a6f1b6283c6188eead2ab1',1,'tacopie::tcp_client::write_result::size()'],['../structtacopie_1_1tcp__client_1_1read__request.html#ad8b69f61884c60596aface363ca947a3',1,'tacopie::tcp_client::read_request::size()']]],
  ['success',['success',['../structtacopie_1_1tcp__client_1_1read__result.html#a9bb917b8d210159a95655a6f8da8e96e',1,'tacopie::tcp_client::read_result::success()'],['../structtacopie_1_1tcp__client_1_1write__result.html#a4a8d5706c83068a97c10e63c6080e6a3',1,'tacopie::tcp_client::write_result::success()']]]
];
