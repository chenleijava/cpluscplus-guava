var searchData=
[
  ['type',['type',['../classtacopie_1_1tcp__socket.html#ad8376e85df96ab9523f5d079ed7172ab',1,'tacopie::tcp_socket']]]
];
